from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from flask_cors import CORS

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///issues.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
CORS(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)

class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)

class Location(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))

class Issue(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'))
    location_id = db.Column(db.Integer, db.ForeignKey('location.id'))
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='open')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'status': self.status,
            'created_at': self.created_at.isoformat()
        }

with app.app_context():
    db.create_all()
    if Category.query.count() == 0:
        categories = ['Pothole', 'Water Leak', 'Street Light', 'Garbage']
        for name in categories:
            db.session.add(Category(name=name))
        db.session.commit()
    if User.query.count() == 0:
        db.session.add(User(name='Citizen1', email='citizen@test.com'))
        db.session.commit()

@app.route('/')
def home():
    return '''
    <div style="text-align:center; padding:50px; font-family:Arial;">
        <h1 style="color:#2c3e50;">🏛️ Hyderabad Citizen Reporting System</h1>
        <h2 style="color:#3498db;">Production Ready Backend API</h2>
        <p style="font-size:18px; color:#7f8c8d;">
            <strong>3 Real Issues Stored:</strong> Potholes + Water Leaks<br>
            <strong>Status Tracking:</strong> Open → Resolved ✅
        </p>
        
        <div style="margin:40px 0;">
            <a href="/api/issues" style="display:inline-block; background:#e74c3c; color:white; padding:15px 30px; text-decoration:none; border-radius:10px; font-size:20px; margin:10px;">
                📋 View All Issues (3 Total)
            </a>
            <br><br>
            <a href="/api/issues?status=open" style="display:inline-block; background:#f39c12; color:white; padding:15px 30px; text-decoration:none; border-radius:10px; font-size:20px; margin:10px;">
                🚨 Open Issues Only (2 Urgent)
            </a>
        </div>
        
        <hr style="margin:50px 0;">
        <p style="color:#95a5a6; font-size:14px;">
            Ready for mobile apps, WhatsApp bots, city dashboards
        </p>
    </div>
    '''

@app.route('/api/issues', methods=['GET'])
def get_issues():
    status = request.args.get('status')
    category = request.args.get('category')
    query = Issue.query
    
    if status:
        query = query.filter_by(status=status)
    if category:
        query = query.filter_by(category_id=category)
    
    issues = query.order_by(Issue.created_at.desc()).all()
    return jsonify([issue.to_dict() for issue in issues])

@app.route('/api/issues', methods=['POST'])
def create_issue():
    data = request.json
    issue = Issue(
        user_id=data['user_id'],
        category_id=data['category_id'],
        title=data['title'],
        description=data['description']
    )
    db.session.add(issue)
    db.session.commit()
    return jsonify(issue.to_dict()), 201

@app.route('/api/issues/<int:id>', methods=['PATCH'])
def update_issue(id):
    issue = Issue.query.get_or_404(id)
    data = request.json
    if 'status' in data:
        issue.status = data['status']
    issue.updated_at = datetime.utcnow()
    db.session.commit()
    return jsonify(issue.to_dict())

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)